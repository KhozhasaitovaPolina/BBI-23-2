﻿using Serialization;

abstract class People
{
    public string Familia;
    public int Prop;
    public int Mark;

    public People(string familia, int mark, int prop)
    {
        Familia = familia;
        Mark = mark;
        Prop = prop;
    }

    public virtual void Printinf()
    {
        Console.WriteLine("Фамилия: {0} \t  Пропуски {1}  ", Familia, Prop);
    }
}
class Informatic : People
{
    public Informatic(string familia, int mark, int prop) : base(familia, mark, prop)
    {

    }
    public override void Printinf()
    {
        Console.WriteLine("Фамилия: {0} \t  Оценка {1}\t  Пропуски {2} ", Familia, Mark, Prop);
    }
}

class Math : People
{
    public Math(string familia, int mark, int prop) : base(familia, mark, prop)
    {

    }
    public override void Printinf()
    {
        Console.WriteLine("Фамилия: {0} \t  Оценка {1}\t  Пропуски {2} ", Familia, Mark, Prop);
    }
}

class Program
{
    static void Main()
    {
        Informatic[] set = new Informatic[6];
        set[0] = new Informatic("Безруков", 4, 2);
        set[1] = new Informatic("Безногов", 2, 8);
        set[2] = new Informatic("Баабайкин", 0, 6);
        set[3] = new Informatic("Бугайкин", 2, 5);
        set[4] = new Informatic("Левошоловин", 5, 0);
        set[5] = new Informatic("Акипов", 2, 4);


        Math[] set1 = new Math[6];
        set1[0] = new Math("Безруков", 5, 2);
        set1[1] = new Math("Безногов", 4, 8);
        set1[2] = new Math("Баабайкин", 2, 6);
        set1[3] = new Math("Бугайкин", 3, 5);
        set1[4] = new Math("Левошоловин", 2, 0);
        set1[5] = new Math("Акипов", 4, 4);

        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Lab9";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string file_name = "9.1.json";

        SerializeManager serializer = new MyJson();

        serializer.Write(set, Path.Combine(path, Path.Combine(path, file_name)));
        set = serializer.Read<Informatic[]>(Path.Combine(path, file_name));
        Console.WriteLine("Информатика");
        for (int i = 0; i < set.Length; i++)
        {
            if (set[i].Mark == 2)
            {
                set[i].Printinf();
            }
        }

        Console.WriteLine();

        serializer.Write(set1, Path.Combine(path, Path.Combine(path, file_name)));
        set1 = serializer.Read<Math[]>(Path.Combine(path, file_name));
        Console.WriteLine("Математика");
        for (int i = 0; i < set1.Length; i++)
        {
            if (set1[i].Mark == 2)
            {
                set1[i].Printinf();
            }
        }
    }
}