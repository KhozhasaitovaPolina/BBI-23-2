﻿
using Newtonsoft.Json;
namespace Serialization
{
    class MyJson : SerializeManager
    {
        public override void Write<T>(T obj, string filePath)
        {
            string json = JsonConvert.SerializeObject(obj);
            File.WriteAllText(filePath, json);
        }

        public override T Read<T>(string filePath)
        {
            string json = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<T>(json);
        }
    }
}
