namespace ConsoleApp1.shapes;

public abstract class Shape
{
    private string name;
    
    protected Shape(){}

    protected Shape(string name)
    {
        this.name = name;
    }

    // публичные геттеры для сериализации
    public string Name => name;

    public override string ToString()
    {
        return $"name: {name}";
    }

    public abstract double CalculatePerimeter();

    public abstract double CalculateArea();
}