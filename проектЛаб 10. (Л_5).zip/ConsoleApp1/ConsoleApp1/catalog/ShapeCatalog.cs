using System.Text.Json.Serialization;
using ConsoleApp1.shapes;

namespace ConsoleApp1.catalog;

public partial class ShapeCatalog : IAnalyzer
{
    private static double EPS = 1e-9; // точность для сравнение дробных чисел
    
    private string name;
    [JsonIgnore]
    private List<Shape> shapes = new List<Shape>(); // лист с фигурами (общий)
    
    // лист с именами фигур, порядок которого соответсвует порядку элементов списка shapes
    private List<string> shapeNames = new List<string>(); 
    // лист с прямоугольниками
    private List<Rectangle> rectangles = new List<Rectangle>();
    // лист с окружностями
    private List<Circle> circles = new List<Circle>();
    // лист с треугольниками
    private List<Triangle> triangles = new List<Triangle>();
    // P.S. эти листы добавлены, для того чтобы нам сохранить подробную информацию о фигурах каталога

    public ShapeCatalog()
    {
    }

    public ShapeCatalog(string name)
    {
        this.name = name;
    }

    // конструктор для десериализации
    [JsonConstructor]
    public ShapeCatalog(string name, List<string> shapeNames, List<Triangle> triangles, List<Rectangle> rectangles, List<Circle> circles)
    {
        this.name = name;
        this.triangles = triangles;
        this.circles = circles;
        this.rectangles = rectangles;
        this.shapeNames = shapeNames;
        // проходимся по именам и восстанавливаем порядок элементов списка shapes
        foreach (var shapeName in shapeNames)
        {
            shapes.Add(FindByName(shapeName));
        }
    }

    // функция нахождения фигуры по имени в списках с треугольниками, окружностями и прямоугольниками
    // private, тк используется только в этом классе (да, мы используем инкапсуляцию по максимуму :D)
    private Shape FindByName(string shapeName)
    {
        foreach (var circle in circles)
        {
            if (circle.Name.Equals(shapeName))
            {
                return circle;
            }
        }
        foreach (var rectangle in rectangles)
        {
            if (rectangle.Name.Equals(shapeName))
            {
                return rectangle;
            }
        }
        foreach (var triangle in triangles)
        {
            if (triangle.Name.Equals(shapeName))
            {
                return triangle;
            }
        }

        return null;
    }
    
    // публичные геттеры для сериализации
    public List<string> ShapeNames => shapeNames;

    public List<Shape> Shapes => shapes;

    public List<Triangle> Triangles => triangles;

    public List<Circle> Circles => circles;

    public List<Rectangle> Rectangles => rectangles;

    public string Name => name;

    // метод добавления в католог фигуры
    // также добавляем по типу фигуры в соответсвующий список
    // если нужно добавить треугольник, то добавим его в shapes и triangles, и добавим имя в список имен
    public void AddShape(Shape shape)
    {
        shapes.Add(shape);
        shapeNames.Add(shape.Name);
        if (shape.GetType() == typeof(Circle))
        {
            circles.Add((Circle)shape);
        }
        else if (shape.GetType() == typeof(Rectangle))
        {
            rectangles.Add((Rectangle)shape);
        }
        else if (shape.GetType() == typeof(Triangle))
        {
            triangles.Add((Triangle)shape);
        }
    }

    // метод удаления фигуры из каталога
    // идентично методу AddShape, удаляем фигуру из списков с соответствующим типом
    public void RemoveShape(Shape shape)
    {
        shapes.Remove(shape);
        shapeNames.Remove(shape.Name);
        if (shape.GetType() == typeof(Circle))
        {
            circles.Remove((Circle)shape);
        }
        else if (shape.GetType() == typeof(Rectangle))
        {
            rectangles.Remove((Rectangle)shape);
        }
        else if (shape.GetType() == typeof(Triangle))
        {
            triangles.Remove((Triangle)shape);
        }
    }
    
    // проверяем, что фигура shape1 описана вокруг фигуры shape2
    public bool IsInscriable(Shape shape1, Shape shape2)
    {
        Circle circle;
        Rectangle rectangle;
        Triangle triangle;
        if (IsCircle(shape1))
        {
            circle = (Circle)shape1;
            if (IsRectangle(shape2))
            {
                rectangle = (Rectangle)shape2;
                // окружность описана вокруг прямоугольника тогда,
                // когда диаметр окружности равен диагонале прямоугольника
                return Math.Abs(2 * circle.R - Math.Sqrt(rectangle.A * rectangle.A + rectangle.B * rectangle.B)) < EPS;
            }
            if (IsTriangle(shape2))
            {
                triangle = (Triangle)shape2;
                // окружность описана вокруг треугольника тогда,
                // когда радиус окружности будет равен радиусу описанной окружности вокруг треугольника
                return Math.Abs(circle.R - triangle.A * triangle.B * triangle.C / (4 * triangle.CalculateArea())) < EPS;
            }
        } else if (IsRectangle(shape1))
        {
            rectangle = (Rectangle)shape1;
            if (IsCircle(shape2) && Math.Abs(rectangle.A - rectangle.B) < EPS)
            {
                circle = (Circle)shape2;
                // прямоугольник будет описан вокруг окружности,
                // когда он будет квадратом (a == b) и диаметр окружности будет равен стороне квадрата
                return Math.Abs(2 * circle.R - rectangle.A) < EPS;
            }
        }
        else if (IsTriangle(shape1))
        {
            triangle = (Triangle)shape1;
            if (IsCircle(shape2))
            {
                circle = (Circle)shape2;
                // треугольник будет описан вокруг окружности,
                // когда радиус вписанной окружности треугольника будет равен радиусу нашей окружности
                return Math.Abs(circle.R - 2 * triangle.CalculateArea() / triangle.CalculatePerimeter()) < EPS;
            }
        }

        return false;
    }

    // проверяем, что фигура shape1 вписана в фигуру shape2
    public bool IsCircumscribed(Shape shape1, Shape shape2)
    {
        // если 1 фигура вписана во 2, то 2 фигура описана вокруг 1
        // а проверять описанность мы уже умеем, поэтому меняем местами фигуры
        return IsInscriable(shape2, shape1);
    }

    // проверяем что данная фигура является прямоугольником
    private bool IsRectangle(Shape shape)
    {
        return shape.GetType() == typeof(Rectangle);
    }
    
    // проверяем что данная фигура является окружностью
    private bool IsCircle(Shape shape)
    {
        return shape.GetType() == typeof(Circle);
    }
    
    // проверяем что данная фигура является треугольников
    private bool IsTriangle(Shape shape)
    {
        return shape.GetType() == typeof(Triangle);
    }
}