using ConsoleApp1.shapes;

namespace ConsoleApp1.catalog;

public partial class ShapeCatalog
{
    public void ShapesInfoCircle()
    {
        int counterCircle = 0;
        double sumAreaCircle = 0;
        double sumPerimeterCircle = 0;
        foreach (var shape in shapes)
        {
            if (shape.GetType() == typeof(Circle))
            {
                counterCircle++;
                sumAreaCircle += shape.CalculateArea();
                sumPerimeterCircle += shape.CalculatePerimeter();
            }
        }

        Console.WriteLine($"Количество кругов: " + counterCircle + ", Средняя площадь: " +
                          sumAreaCircle / counterCircle + ", Средний периметр: " +
                          sumPerimeterCircle / counterCircle);
    }

    public void ShapesInfoTriangle()
    {
        int counterTriangle = 0;
        double sumAreaTriangle = 0;
        double sumPerimeterTriangle = 0;
        foreach (var shape in shapes)
        {
            if (shape.GetType() == typeof(Triangle))
            {
                counterTriangle++;
                sumAreaTriangle += shape.CalculateArea();
                sumPerimeterTriangle += shape.CalculatePerimeter();
            }
        }

        Console.WriteLine($"Количество треугольников: " + counterTriangle + ", Средняя площадь: " +
                           sumAreaTriangle / counterTriangle + ", Средний периметр: " +
                           sumPerimeterTriangle / counterTriangle);
    }

    public void ShapesInfoRectangle()
    {
        int counterRectangle = 0;
        double sumAreaRectangle = 0;
        double sumPerimeterRectangle = 0;
        foreach (var shape in shapes)
        {
            if (shape.GetType() == typeof(Rectangle))
            {
                counterRectangle++;
                sumAreaRectangle += shape.CalculateArea();
                sumPerimeterRectangle += shape.CalculatePerimeter();
            }
        }

        Console.WriteLine($"Количество прямоугольников: " + counterRectangle + ", Средняя площадь: " +
                          sumAreaRectangle / counterRectangle + ", Средний периметр: " +
                          sumPerimeterRectangle / counterRectangle);
    }
}